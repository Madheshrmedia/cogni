<link rel="stylesheet" href="style.css">
<?php
include_once "./header.php";
?>
<div class="hero" style="background-image: url(./image/rect1.webp);padding-top: 23rem;">
</div>
<!-- === -->
<div class="container" style="margin:3rem auto">
  <h3>Achieve Flawless Skin with Our Advanced Laser Treatments</h3><br>
  <h3>Permanent Hair Removal</h3>
  <ul>
    <li><span class="black">Modern Diode Laser System: </span> Multi-wavelength technology, making it safe for various
      skin types, including darker skin. The cooling mechanism ensures patient comfort, making the procedure more
      tolerable and safer.</li><br>
    <li><span class="black">Efficient and Effective:</span> With a large tip (12mm x 16 mm) for extensive coverage, you
      can achieve permanent hair reduction in fewer sessions. Say goodbye to traditional methods like shaving or waxing!
    </li><br>


  </ul><br>
  <h3>Laser Skin Care</h3>
  <ul>
    <li><span class="black">Pico Laser Treatment: </span> This cutting-edge, non-invasive technology addresses various
      skin concerns such as pigmentation issues, acne scars, skin rejuvenation, and black & colour tattoo removal.</li>
    <br>

  </ul>

</div>
<!-- === -->
<div class="cardbig">
  <div class="heading">
    <h2>LASER HAIR REDUCTION
    </h2>
  </div>

  <div class="container" id="cardcontainer">
    <div class="row g-0 text-center">
      <div class="col-sm-6 col-md-5" style="text-align:left">
        <p>FULL BODY



        </p>
        <p>CHIN



        </p>
        <p>FULL FACE



        </p>
        <p>FULL ARMS

        </p>
        <p>UNDER ARMS

        </p>
        <p>BIKINI


        </p>
      </div>
      <div class="col-sm-6 col-md-2"></div>
      <div class="col-sm-6 col-md-5" style="text-align:left">

        <p>UPPERLIP
        </p>
        <p>SIDELOCKS

        </p>
        <p>EAR LOBE

        </p>
        <p>FULL LEGS

        </p>
        <p>ABDOMEN/HALF BACK


        </p>
        <p>LOWER FACE


        </p>
      </div>
    </div>
  </div>
  <div class="button">
    <button class="book" style="border: none;" data-bs-toggle="modal" data-bs-target="#exampleModal">BOOK NOW</button>
  </div>

</div>
<!-- === -->
<div class="cardbig">
  <div class="heading">
    <h2>PICO LASER



    </h2>
  </div>

  <div class="container" id="cardcontainer">
    <div class="row g-0 text-center">
      <div class="col-sm-6 col-md-5" style="text-align:left">
        <p>ACNE SCAR REMOVAL



        </p>
        <p>PIGMENTATION REMOVAL

        </p>
        <p>COLOR TATTOO REMOVAL

        </p>
        <p>BOLLYWOOD FACIAL


        </p>
      </div>
      <div class="col-sm-6 col-md-2"></div>
      <div class="col-sm-6 col-md-5" style="text-align:left">

        <p>SKIN REJUVANATION </p>
        <p>TATTOO REMOVAL </p>
        <p>CARBON FACIAL
        </p>

      </div>
    </div>
  </div>
  <div class="button">
    <button class="book" style="border: none;" data-bs-toggle="modal" data-bs-target="#exampleModal">BOOK NOW</button>
  </div>
  <!-- Modal -->
  <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl">
      <div class="modal-content">
        <div class="modal-header">
          <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          ...
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="button" class="btn btn-primary">Save changes</button>
        </div>
      </div>
    </div>
  </div>
</div> <br>
<!-- === -->
<style>

</style>

<div class="container">
  <p>Experience the transformation with our advanced laser treatments and achieve the look you’ve always wanted!</p>


</div><br><br>

<style>
  .heading {
    text-align: center;
    background-color: #F1FFF3;
    padding: 1rem 0;
    margin-bottom: 1rem;

  }

  .heading h2 {
    margin-bottom: 0 !important;
  }

  #cardcontainer {
    max-width: 1100px;
  }

  #cardcontainer p {
    padding: 1rem;
    border-bottom: 1px solid #9BB7BF;
  }

  .button {
    text-align: center;
    margin: 3rem auto 5rem auto;
  }

  .book {
    background: linear-gradient(to right,
        #D4A200 0%,
        /* Stop at 0% */
        #FFD13D 43%,
        /* Stop at 43% */
        #D6A608 75%,
        /* Stop at 75% */
        #FFC300 100%
        /* Stop at 100% */
      );
    border: none;
    padding: 10px 36px;
    color: #fff;
    font-size: 13px;
  }
</style>

<!-- === -->
<?php
include_once "./footer.php";
?>